(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_24ec6a29._.js",
  "static/chunks/a2414_next_dist_compiled_react-dom_a5de6696._.js",
  "static/chunks/a2414_next_dist_compiled_next-devtools_index_29ef1a45.js",
  "static/chunks/a2414_next_dist_compiled_b4d3c36c._.js",
  "static/chunks/a2414_next_dist_client_7b454cfb._.js",
  "static/chunks/a2414_next_dist_1ede9c24._.js",
  "static/chunks/69652_@swc_helpers_cjs_77b72907._.js"
],
    source: "entry"
});
