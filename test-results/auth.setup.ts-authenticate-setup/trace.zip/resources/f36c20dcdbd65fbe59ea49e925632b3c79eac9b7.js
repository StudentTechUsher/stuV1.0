(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/bdf11_@supabase_node-fetch_browser_bdf434ac.js",
  "static/chunks/_84ac2e3b._.js",
  "static/chunks/node_modules__pnpm_e1dc1cf8._.js",
  "static/chunks/app_8901dc4d._.css"
],
    source: "dynamic"
});
